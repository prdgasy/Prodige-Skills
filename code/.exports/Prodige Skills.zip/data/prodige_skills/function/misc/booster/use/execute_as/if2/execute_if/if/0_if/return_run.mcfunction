execute if entity @p[tag=prodige_skills.player.sound] at @p run playsound entity.enderman.teleport master @p ~ ~ ~ 1 1
tellraw @p "§c[Prodige Skill] §8• §cYou already have an active Pts Booster!"