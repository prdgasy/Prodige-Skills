scoreboard players add @p prodige_skills.reward.pending.canopy_hatchet 1
tellraw @a [{text: " \u00A78\u2022 §9Canopy Hatchet"}]
scoreboard players set anon_cnoL-r-9_9090 __sandstone 1