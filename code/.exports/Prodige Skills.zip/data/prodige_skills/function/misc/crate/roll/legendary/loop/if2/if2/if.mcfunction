scoreboard players operation anon_cnoL-r-9_9115 __sandstone = anon_cnoL-r-9_9110 __sandstone
scoreboard players operation anon_cnoL-r-9_9115 __sandstone *= 10 __sandstone
scoreboard players operation @p prodige_skills.foraging.xp += anon_cnoL-r-9_9115 __sandstone