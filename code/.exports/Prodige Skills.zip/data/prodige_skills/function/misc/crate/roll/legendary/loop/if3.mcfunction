scoreboard players add @p prodige_skills.reward.pending.x4_xp_booster 1
tellraw @a [{text: " \u00A78\u2022 §bx4 Xp Booster"}]
scoreboard players set anon_cnoL-r-9_9109 __sandstone 1