scoreboard players add @p prodige_skills.reward.pending.sapling_cutter 1
tellraw @a [{text: " \u00A78\u2022 §aSapling Cutter"}]
scoreboard players set anon_cnoL-r-9_9052 __sandstone 1