scoreboard players operation anon_cnoL-r-9_9080 __sandstone = anon_cnoL-r-9_9072 __sandstone
scoreboard players operation anon_cnoL-r-9_9080 __sandstone *= 10 __sandstone
scoreboard players operation @p prodige_skills.farming.xp += anon_cnoL-r-9_9080 __sandstone